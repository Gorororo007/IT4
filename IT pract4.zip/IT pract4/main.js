class Event {
    constructor(id, title, date, category, description) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.category = category;
        this.description = description;
    }
}

class EventManager {
    constructor() {
        this.events = JSON.parse(localStorage.getItem('events')) || [];
        this.setupEventListeners();
        this.renderEvents();
    }

    setupEventListeners() {
        const addEventForm = document.getElementById('addEventForm');
        if (addEventForm) {
            addEventForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.addEvent();
            });
        }

        const editEventForm = document.getElementById('editEventForm');
        if (editEventForm) {
            editEventForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.updateEvent();
            });
        }

        const deleteButton = document.getElementById('deleteEvent');
        if (deleteButton) {
            deleteButton.addEventListener('click', () => {
                if (confirm('Мяу? Ты уверен, что хочешь удалить это событие? 😿')) {
                    this.deleteEvent();
                }
            });
        }

        const categoryFilter = document.getElementById('categoryFilter');
        const sortOrder = document.getElementById('sortOrder');
        
        if (categoryFilter && sortOrder) {
            categoryFilter.addEventListener('change', () => this.renderEvents());
            sortOrder.addEventListener('change', () => this.renderEvents());
        }

        if (window.location.pathname.includes('edit.html')) {
            this.loadEventForEditing();
        }
    }

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    addEvent() {
        const title = document.getElementById('eventTitle').value;
        const date = document.getElementById('eventDate').value;
        const category = document.getElementById('eventCategory').value;
        const description = document.getElementById('eventDescription').value;

        const newEvent = new Event(
            this.generateId(),
            title,
            date,
            category,
            description
        );

        this.events.push(newEvent);
        this.saveEvents();
        window.location.href = 'main.html';
    }

    updateEvent() {
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('id');

        const title = document.getElementById('eventTitle').value;
        const date = document.getElementById('eventDate').value;
        const category = document.getElementById('eventCategory').value;
        const description = document.getElementById('eventDescription').value;

        const eventIndex = this.events.findIndex(event => event.id === eventId);
        if (eventIndex !== -1) {
            this.events[eventIndex] = new Event(
                eventId,
                title,
                date,
                category,
                description
            );
            this.saveEvents();
            window.location.href = 'main.html';
        }
    }

    deleteEvent() {
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('id');

        this.events = this.events.filter(event => event.id !== eventId);
        this.saveEvents();
        window.location.href = 'main.html';
    }

    loadEventForEditing() {
        const urlParams = new URLSearchParams(window.location.search);
        const eventId = urlParams.get('id');

        const event = this.events.find(event => event.id === eventId);
        if (event) {
            document.getElementById('eventTitle').value = event.title;
            document.getElementById('eventDate').value = event.date;
            document.getElementById('eventCategory').value = event.category;
            document.getElementById('eventDescription').value = event.description;
        }
    }

    saveEvents() {
        localStorage.setItem('events', JSON.stringify(this.events));
    }

    filterEvents() {
        const categoryFilter = document.getElementById('categoryFilter');
        const selectedCategory = categoryFilter ? categoryFilter.value : '';

        return this.events.filter(event => {
            if (!selectedCategory) return true;
            return event.category === selectedCategory;
        });
    }

    sortEvents(events) {
        const sortOrder = document.getElementById('sortOrder');
        const order = sortOrder ? sortOrder.value : 'asc';

        return events.sort((a, b) => {
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
            return order === 'asc' ? dateA - dateB : dateB - dateA;
        });
    }

    getCategoryIcon(category) {
        const icons = {
            personal: 'fas fa-cat',
            work: 'fas fa-paw',
            public: 'fas fa-user-friends'
        };
        return icons[category] || 'fas fa-calendar';
    }

    getCategoryLabel(category) {
        const labels = {
            personal: 'Мурчалки',
            work: 'Охотники',
            public: 'Гуляки'
        };
        return labels[category] || category;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        if (date.toDateString() === today.toDateString()) {
            return `Сегодня, ${date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`;
        }
        
        if (date.toDateString() === tomorrow.toDateString()) {
            return `Завтра, ${date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`;
        }
        
        return date.toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    createEventCard(event) {
        const card = document.createElement('div');
        card.className = 'event-card';
        card.onclick = () => window.location.href = `edit.html?id=${event.id}`;

        const categoryIcon = this.getCategoryIcon(event.category);
        const categoryLabel = this.getCategoryLabel(event.category);
        const formattedDate = this.formatDate(event.date);
        
        let description = event.description || '';
        if (description.length > 100) {
            description = description.substring(0, 100) + '...';
        }

        card.innerHTML = `
            <h3>${event.title}</h3>
            <div class="date"><i class="far fa-clock"></i> ${formattedDate}</div>
            <div class="category"><i class="${categoryIcon}"></i> ${categoryLabel}</div>
            <div class="description">${description}</div>
        `;

        return card;
    }

    renderEvents() {
        const container = document.getElementById('eventsContainer');
        if (!container) return;

        const filteredEvents = this.filterEvents();
        const sortedEvents = this.sortEvents(filteredEvents);

        container.innerHTML = '';
        
        if (sortedEvents.length === 0) {
            container.innerHTML = `
                <div class="no-events">
                    <i class="far fa-calendar-times"></i>
                    <p>Нет событий для отображения</p>
                    <p>Добавь первое событие, нажав на лапку внизу!</p>
                </div>
            `;
            return;
        }
        
        sortedEvents.forEach((event, index) => {
            const card = this.createEventCard(event);
            card.style.animationDelay = `${index * 0.1}s`;
            container.appendChild(card);
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {
    new EventManager();
});